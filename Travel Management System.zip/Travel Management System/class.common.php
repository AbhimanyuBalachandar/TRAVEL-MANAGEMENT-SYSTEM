<?php
class Common {

    public static function formatNumber($number) {
        return number_format((float)$number, 2, '.', '');
    }

    public static function displayImage($img_path, $default_img) {
        if($img_path == ""){
            // Default image path
            $img_path = $default_img;
        }
        if (isset($img_path) && file_exists($img_path)) {
            // Image parameter exists and file exists
            $img_path = $img_path;
        } else {
            // Default image path
            $img_path = $default_img;
        }
    }
}
?>