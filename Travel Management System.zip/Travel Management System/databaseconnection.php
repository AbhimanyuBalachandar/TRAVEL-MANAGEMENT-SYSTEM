<?php
// Create connection
$con=mysqli_connect("localhost","root","","freefriendlytravelmood","3307");
// Check connection,
echo mysqli_connect_error();
?>