<?php
include("header.php");
?> 
            <!-- Sub Banner Start-->
            <div class="mg_sub_banner">
                <div class="container">
                    <h2>blog full</h2>
                    <ul class="breadcrumb">
                        <li><a href="#">home</a></li>
                        <li class="active"><span>blog full</span></li>
                    </ul>
                </div>
            </div>
            <!-- Sub Banner End-->
            <!-- Main Contant Wrap Start-->
            <div class="iqoniq_contant_wrapper">
                <section>
                    <div class="container">
                        <div class="row">
                            <!-- Blog Full Wrap Start-->
                            <div class="col-md-8">
                                <!-- Blog Full Strat -->
                                <div class="mg_blog_full fancy-overlay">
                                    <div class="thumb">
                                        <img src="extra-images/blog-full.jpg" alt="">
                                        <div class="mg_date">
                                            <b>28</b><small>Nov</small>
                                        </div>
                                    </div>
                                    <div class="mg_blog_contant">
                                        <div class="mg_blog_meta">
                                            <a href="#"><i class="fa fa-user"></i><span>John Doe</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>345</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>hotel, enjoyment. dubai</span></a>
                                        </div>
                                        <h5 class="blog_title"><a href="#">Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus.</a></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Idque Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus. Magna pars studiorum, prodita quaerimus. Fabio vel iudice vincam, sunt in culpa qui officia. Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>
                                        <a class="mg_btn1" href="#">Read More</a>
                                    </div>
                                </div>
                                <!-- Blog Full End -->
                                <!-- Blog Full Strat -->
                                <div class="mg_blog_full">
                                    <div class="thumb audio_thumb">
                                        <iframe  src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/92489679&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                                    </div>
                                    <div class="mg_blog_contant">
                                        <div class="mg_blog_meta">
                                            <a href="#"><i class="fa fa-user"></i><span>John Doe</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>345</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>hotel, enjoyment. dubai</span></a>
                                        </div>
                                        <h5 class="blog_title"><a href="#">Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus.</a></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Idque Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus. Magna pars studiorum, prodita quaerimus. Fabio vel iudice vincam, sunt in culpa qui officia. Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>
                                        <a class="mg_btn1" href="#">Read More</a>
                                    </div>
                                </div>
                                <!-- Blog Full End -->
                                <!-- Blog Full Strat -->
                                <div class="mg_blog_full">
                                    <div class="thumb">
                                        <div class="mg_blog_full-slider">
                                            <div>
                                                <img src="extra-images/blog-full2.jpg" alt="">
                                            </div>
                                            <div>
                                                <img src="extra-images/blog-full3.jpg" alt="">
                                            </div>
                                            <div>
                                                <img src="extra-images/blog-full4.jpg" alt="">
                                            </div>
                                        </div>
                                        <div class="mg_date">
                                            <b>22</b><small>Nov</small>
                                        </div>
                                    </div>
                                    <div class="mg_blog_contant">
                                        <div class="mg_blog_meta">
                                            <a href="#"><i class="fa fa-user"></i><span>John Doe</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>345</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>hotel, enjoyment. dubai</span></a>
                                        </div>
                                        <h5 class="blog_title"><a href="#">Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus.</a></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Idque Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus. Magna pars studiorum, prodita quaerimus. Fabio vel iudice vincam, sunt in culpa qui officia. Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>
                                        <a class="mg_btn1" href="#">Read More</a>
                                    </div>
                                </div>
                                <!-- Blog Full End -->
                                <!-- Blog Full Strat -->
                                <div class="mg_blog_full">
                                    <div class="thumb video_thumb">
                                        <iframe src="https://player.vimeo.com/video/100779503?color=960&amp;title=0&amp;byline=0&amp;portrait=0"></iframe>
                                    </div>
                                    <div class="mg_blog_contant">
                                        <div class="mg_blog_meta">
                                            <a href="#"><i class="fa fa-user"></i><span>John Doe</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>345</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>hotel, enjoyment. dubai</span></a>
                                        </div>
                                        <h5 class="blog_title"><a href="#">Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus.</a></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Idque Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus. Magna pars studiorum, prodita quaerimus. Fabio vel iudice vincam, sunt in culpa qui officia. Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>
                                        <a class="mg_btn1" href="#">Read More</a>
                                    </div>
                                </div>
                                <!-- Blog Full End -->
                                <!-- Blog Full Strat -->
                                <div class="mg_blog_full fancy-overlay">
                                    <div class="thumb">
                                        <img src="extra-images/blog-full3.jpg" alt="">
                                        <div class="mg_date">
                                            <b>30</b><small>Nov</small>
                                        </div>
                                    </div>
                                    <div class="mg_blog_contant">
                                        <div class="mg_blog_meta">
                                            <a href="#"><i class="fa fa-user"></i><span>John Doe</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>345</span></a>
                                            <a href="#"><i class="fa fa-user"></i><span>hotel, enjoyment. dubai</span></a>
                                        </div>
                                        <h5 class="blog_title"><a href="#">Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus.</a></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Idque Caesaris facere voluntate liceret: sese habere. Magna pars studiorum, prodita quaerimus. Magna pars studiorum, prodita quaerimus. Fabio vel iudice vincam, sunt in culpa qui officia. Vivamus sagittis lacus vel augue laoreet rutrum faucibus.</p>
                                        <a class="mg_btn1" href="#">Read More</a>
                                    </div>
                                </div>
                                <!-- Blog Full End -->
                                <!-- Pagination Start-->
                                <div class="mg_pagination text-center">
                                    <span class="page-numbers current">1</span>
                                    <a class="page-numbers" href="#">2</a>
                                    <a class="page-numbers" href="#">3</a>
                                    <a class="page-numbers border_none" href="#">...</a>
                                    <a class="page-numbers" href="#">18</a>
                                    <a class="page-numbers" href="#">19</a>
                                    <a class="page-numbers" href="#">20</a>
                                </div>
                                <!-- Pagination End-->
                            </div>
                            <!-- Blog Full Wrap End-->
                            <!-- Sidebar Start-->
                            <div class="col-md-4">
                                <div class="mg_sidebar">
                                    <!-- Widget Search Start-->
                                    <div class="widget widget_search">
                                        <div class="border-bottom">
                                            <div class="mg_input_1">
                                                <input type="text" placeholder="Search keyword">
                                                <label class="search_icon"><input type="submit"></label>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Widget Search End-->
                                    <!-- Widget Contant Start-->
                                    <div class="widget widget_contant">
                                        <div class="border-bottom">
                                            <h5 class="widget_default_title">Text Widget</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Idque Caesaris fac liceret: sese habere. Magna pars studiorum, prodita quaerimus. Magna pars studiorum, prodita quaerimus. Fabio vel iudice vincam,.</p>
                                        </div>
                                    </div>
                                    <!-- Widget Contant End-->
                                    <!-- Widget Recent Post Start-->
                                    <div class="widget widget_recent_post">
                                        <div class="border-bottom">
                                            <h5 class="widget_default_title">Recent Blogs</h5>
                                            <!-- Recent Post Start -->
                                            <div class="recent_post fancy-overlay">
                                                <figure><img src="extra-images/recent_blog.jpg" alt=""></figure>
                                                <div class="overflow_text">
                                                    <h5><a href="#">Recent Blogs</a> <span><i class="fa fa-clock"></i>04 Dec 2013</span></h5>
                                                    <p>Magna pars studiorum, prodita quaerimus. Magna pars studiorum, </p>
                                                </div>
                                            </div>
                                            <!-- Recent Post End -->
                                            <!-- Recent Post Start -->
                                            <div class="recent_post fancy-overlay">
                                                <figure><img src="extra-images/recent_blog.jpg" alt=""></figure>
                                                <div class="overflow_text">
                                                    <h5><a href="#">Recent Blogs</a> <span><i class="fa fa-clock"></i>04 Dec 2013</span></h5>
                                                    <p>Magna pars studiorum, prodita quaerimus. Magna pars studiorum, </p>
                                                </div>
                                            </div>
                                            <!-- Recent Post End -->
                                            <!-- Recent Post Start -->
                                            <div class="recent_post fancy-overlay">
                                                <figure><img src="extra-images/recent_blog.jpg" alt=""></figure>
                                                <div class="overflow_text">
                                                    <h5><a href="#">Recent Blogs</a> <span><i class="fa fa-clock"></i>04 Dec 2013</span></h5>
                                                    <p>Magna pars studiorum, prodita quaerimus. Magna pars studiorum, </p>
                                                </div>
                                            </div>
                                            <!-- Recent Post End -->
                                            <!-- Recent Post Start -->
                                            <div class="recent_post fancy-overlay">
                                                <figure><img src="extra-images/recent_blog.jpg" alt=""></figure>
                                                <div class="overflow_text">
                                                    <h5><a href="#">Recent Blogs</a> <span><i class="fa fa-clock"></i>04 Dec 2013</span></h5>
                                                    <p>Magna pars studiorum, prodita quaerimus. Magna pars studiorum, </p>
                                                </div>
                                            </div>
                                            <!-- Recent Post End -->
                                        </div>
                                    </div>
                                    <!-- Widget Recent Post End-->
                                    <!-- Widget Rss Start-->
                                    <div class="widget widget_rss">
                                        <div class="border-bottom">
                                            <h5 class="widget_default_title">Recent Comments</h5>
                                            <ul class="mg_rss_list">
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                                <li><span> John Doe on </span><a href="#">Magna pars studiorum</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Widget Rss End-->
                                    <!-- Widget Tags Start-->
                                    <div class="widget widget_tag">
                                        <div class="border-bottom">
                                            <h5 class="widget_default_title">tags</h5>
                                            <div class="tag_list">
                                                <a class="tag" href="#">Hotel</a>
                                                <a class="tag" href="#">Booking</a>
                                                <a class="tag" href="#">Room</a>
                                                <a class="tag" href="#">iqoniq themes</a>
                                                <a class="tag" href="#">Blog</a>
                                                <a class="tag" href="#">lifestyle</a>
                                                <a class="tag" href="#">Gallery Thumbnail</a>
                                                <a class="tag" href="#">Hotel</a>
                                                <a class="tag" href="#">Booking</a>
                                                <a class="tag" href="#">Room</a>
                                                <a class="tag" href="#">iqoniq themes</a>
                                                <a class="tag" href="#">Blog</a>
                                                <a class="tag" href="#">lifestyle</a>
                                                <a class="tag" href="#">Gallery Thumbnail</a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Widget Tags End-->
                                </div>
                            </div>
                            <!-- Side Bar End-->
                        </div>
                    </div>
                </section>
            </div>
            <!-- Main Contant Wrap End-->
<?php
include("footer.php");
?> 
