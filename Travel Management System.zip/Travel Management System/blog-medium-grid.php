<?php
include("header.php");
?> 
            <!-- Sub Banner Start -->
            <div class="mg_sub_banner">
                <div class="container">
                    <h2>Blog Medium Grid</h2>
                    <ul class="breadcrumb">
                        <li><a href="#">home</a></li>
                        <li class="active"><span>Blog Medium Grid</span></li>
                    </ul>
                </div>
            </div>
            <!-- Sub Banner End -->
            <!-- Main Contant Wrap Start -->
            <div class="iqoniq_contant_wrapper">
                <section>
                    <div class="container">
                        <div class="row">
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium1.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium2.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium3.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium1.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium2.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium3.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium1.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium2.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium3.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium1.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium2.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                            <!-- iqoniq Blog Medium Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_medium fancy-overlay">
                                    <h6><a href="#">Its A Brillaint city to visit</a></h6>
                                    <figure>
                                        <a href="#"><img src="extra-images/blog_medium3.jpg" alt=""></a>
                                    </figure>
                                    <div class="text">
                                        <ul class="blog-meta-list">
                                            <li><a href="#"><i class="fa fa-calendar"></i><span>24 Aug 2016</span></a></li>
                                            <li><a href="#"><i class="fa fa-comments-o"></i><span>24 comments</span></a></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy </p>
                                        <a class="mg_readmore" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Medium End -->
                        </div>
                    </div>
                </section>
            </div>
            <!-- Main Contant Wrap End -->
<?php
include("footer.php");
?> 
