<?php
include("header.php");
?> 
            <!-- Sub Banner Start -->
            <div class="mg_sub_banner">
                <div class="container">
                    <h2>Blog Medium Grid 3</h2>
                    <ul class="breadcrumb">
                        <li><a href="#">home</a></li>
                        <li class="active"><span>Blog Medium Grid 3</span></li>
                    </ul>
                </div>
            </div>
            <!-- Sub Banner Start -->
            <!-- Main Contant Wrap Start -->
            <div class="iqoniq_contant_wrapper">
                <section>
                    <div class="container">
                        <div class="row">
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid2.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid3.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid4.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid5.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid6.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid7.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid8.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-4 col-sm-6">
                                <div class="mg_blog_listing fancy-overlay">
                                    <div class="thumb">
                                        <a href="#"><img src="extra-images/news_grid9.jpg" alt=""></a>
                                        <a class="mg_zoom_icon" href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                    <div class="text">
                                        <h5 class="blog_title"><a href="#">consetetur sadipscing</a></h5>
                                        <ul class="blog-meta-list">
                                            <li><span>Monday April 22nd, 2015</span></li>
                                        </ul>
                                        <div class="clear"></div>
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam invidunt ut labore et dolore magna aliquyam</p>
                                        <a class="mg_btn1 bg_transparent" href="#">Read more</a>
                                    </div>
                                </div>
                            </div>
                            <!-- iqoniq Blog Listing Start -->
                            <div class="col-md-12">
                                <!-- Pagination Start-->
                                <div class="mg_pagination text-center">
                                    <span class="page-numbers current">1</span>
                                    <a class="page-numbers" href="#">2</a>
                                    <a class="page-numbers" href="#">3</a>
                                    <a class="page-numbers border_none" href="#">...</a>
                                    <a class="page-numbers" href="#">18</a>
                                    <a class="page-numbers" href="#">19</a>
                                    <a class="page-numbers" href="#">20</a>
                                </div>
                                <!-- Pagination End-->
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <!-- Main Contant Wrap End -->
 <?php
include("footer.php");
?>          
