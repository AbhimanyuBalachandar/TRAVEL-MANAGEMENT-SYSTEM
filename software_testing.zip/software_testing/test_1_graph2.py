import json
import matplotlib.pyplot as plt
import seaborn as sns

# Set Seaborn style
sns.set(style="whitegrid")

# Your JSON data
json_data = '''
{
  "id": "41ae4700-da5b-4084-8d78-b0a9f47c3c8c",
  "version": "2.0",
  "name": "SoftwareEngineering",
  "url": "http://localhost/tourstravel/staffchangepassword.php",
  "tests": [{
    "id": "ba20d2e9-03e6-4640-b1f2-eaba44c17799",
    "name": "Customer Login",
    "commands": [
      {"id": "36f12fc1-99ce-49a4-9340-2df260390247", "comment": "", "command": "open", "target": "/tourstravel/", "targets": [], "value": "1.5"},
      {"id": "a12b34cd-56ef-7890-12ab-cd345ef67890", "comment": "", "command": "click", "target": "button", "targets": [], "value": "2.0"},
      {"id": "d34e56fg-789h-012i-345j-klm678no901p", "comment": "", "command": "type", "target": "input", "targets": [], "value": "3.5"}
    ]
  }]
}
'''

# Parse JSON data
data = json.loads(json_data)

# Extract relevant data for plotting
test_names = [f"{test['name']} - {command['command']}" for test in data['tests'] for command in test['commands']]
command_values = [float(command['value']) for test in data['tests'] for command in test['commands']]

# Create a scatter plot
fig, ax = plt.subplots(figsize=(10, 6))
sns.scatterplot(x=test_names, y=command_values, color='purple', ax=ax)

# Customize the chart
ax.set_xlabel('Test Command')
ax.set_ylabel('Command Value')
ax.set_title('Selenium Test Data - Scatter Plot of Sample 1')

# Show the plot
plt.xticks(rotation=45, ha='right')  # Rotate test commands for better readability
plt.tight_layout()
plt.show()
