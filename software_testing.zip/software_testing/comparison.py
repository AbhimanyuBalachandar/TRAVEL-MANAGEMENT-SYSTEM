import json
import matplotlib.pyplot as plt
import pandas as pd

# JSON data for both snippets
json_data_1 = '''
{
  "id": "4bb7da1c-363e-49bc-a5c6-55dfaadb2b6d",
  "comment": "",
  "command": "setWindowSize",
  "target": "1280x672",
  "targets": [],
  "value": ""
}
'''

json_data_2 = '''
{
  "id": "4bb7da1c-363e-49bc-a5c6-55dfaadb2b6d",
  "comment": "",
  "command": "click",
  "target": "button",
  "targets": [],
  "value": ""
}
'''

# Parse JSON data
data_1 = json.loads(json_data_1)
data_2 = json.loads(json_data_2)

# Extract relevant data for plotting
command_statuses_1 = ['Success' if 'assert' not in data_1['command'] else 'Failure']
command_statuses_2 = ['Success' if 'assert' not in data_2['command'] else 'Failure']

# Count the occurrences of each status for both snippets
status_counts_1 = {'Success': command_statuses_1.count('Success'), 'Failure': command_statuses_1.count('Failure')}
status_counts_2 = {'Success': command_statuses_2.count('Success'), 'Failure': command_statuses_2.count('Failure')}

# Create a DataFrame for easy plotting
df = pd.DataFrame({'setWindowSize': status_counts_1, 'click': status_counts_2})

# Grouped bar chart
ax = df.plot(kind='bar', color=['green', 'red'])
ax.set_ylabel('Count')
ax.set_title('Comparison of Command Status of the 2 samples')
plt.show()
