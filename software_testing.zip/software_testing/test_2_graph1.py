import json
import matplotlib.pyplot as plt
import seaborn as sns

# Set Seaborn style
sns.set(style="whitegrid")

# Your JSON data
json_data = '''
{
  "id": "4bb7da1c-363e-49bc-a5c6-55dfaadb2b6d",
  "comment": "",
  "command": "setWindowSize",
  "target": "1280x672",
  "targets": [],
  "value": ""
}
'''

# Parse JSON data
data = json.loads(json_data)

# Extract relevant data for plotting
command_statuses = ['Success' if 'assert' not in data['command'] else 'Failure']

# Count the occurrences of each status
status_counts = {status: command_statuses.count(status) for status in set(command_statuses)}

# Create a pie chart
plt.pie(status_counts.values(), labels=status_counts.keys(), autopct='%1.1f%%', startangle=90, colors=['green', 'red'])
plt.title('Distribution of Successful and Failed Commands for Sample 2')
plt.show()
