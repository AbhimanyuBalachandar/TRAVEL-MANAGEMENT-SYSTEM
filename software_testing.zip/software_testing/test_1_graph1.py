import json
import matplotlib.pyplot as plt
import seaborn as sns

# Set Seaborn style
sns.set(style="whitegrid")

# Your JSON data
json_data = '''
{
  "id": "41ae4700-da5b-4084-8d78-b0a9f47c3c8c",
  "version": "2.0",
  "name": "SoftwareEngineering",
  "url": "http://localhost/tourstravel/staffchangepassword.php",
  "tests": [{
    "id": "ba20d2e9-03e6-4640-b1f2-eaba44c17799",
    "name": "Customer Login",
    "commands": [
      {"id": "36f12fc1-99ce-49a4-9340-2df260390247", "comment": "", "command": "open", "target": "/tourstravel/", "targets": [], "value": "1.5"},
      {"id": "a12b34cd-56ef-7890-12ab-cd345ef67890", "comment": "", "command": "click", "target": "button", "targets": [], "value": "2.0"},
      {"id": "d34e56fg-789h-012i-345j-klm678no901p", "comment": "", "command": "type", "target": "input", "targets": [], "value": "3.5"}
    ]
  }]
}
'''

# Parse JSON data
data = json.loads(json_data)

# Extract relevant data for plotting
command_statuses = ['Success' if 'assert' not in command['command'] else 'Failure' for test in data['tests'] for command in test['commands']]

# Count the occurrences of each status
status_counts = {status: command_statuses.count(status) for status in set(command_statuses)}

# Create a pie chart
fig, ax = plt.subplots(figsize=(8, 8))
ax.pie(status_counts.values(), labels=status_counts.keys(), autopct='%1.1f%%', startangle=90, colors=['green', 'red'])
ax.set_title('Distribution of Successful and Failed Commands for Sample 1')

# Show the plot
plt.show()



