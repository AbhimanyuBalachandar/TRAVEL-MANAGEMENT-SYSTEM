import json
import matplotlib.pyplot as plt

# Your JSON data
json_data = '''
{
  "id": "4bb7da1c-363e-49bc-a5c6-55dfaadb2b6d",
  "comment": "",
  "command": "setWindowSize",
  "target": "1280x672",
  "targets": [],
  "value": ""
}
'''

# Parse JSON data
data = json.loads(json_data)

# Extract relevant data for plotting
command_statuses = ['Success' if 'assert' not in data['command'] else 'Failure']

# Count the occurrences of each status
status_counts = {'Success': command_statuses.count('Success'), 'Failure': command_statuses.count('Failure')}

# Scatter plot
plt.scatter([1], [status_counts.get('Success', 0)], color='green', label='Success')
plt.scatter([1], [status_counts.get('Failure', 0)], color='red', label='Failure')
plt.xticks([1], ['setWindowSize'])
plt.title('Scatter Plot of Command Status for Sample 2')
plt.legend()
plt.show()
